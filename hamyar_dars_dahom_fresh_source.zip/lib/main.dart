import 'dart:ui';
import 'package:flutter/material.dart';

void main() => runApp(const HamyarApp());

const navy = Color(0xFF090D1D);
const panel = Color(0xFF171D36);
const purple = Color(0xFF9A7BFF);
const blue = Color(0xFF58C7FF);
const muted = Color(0xFFADB7D5);

class HamyarApp extends StatelessWidget {
  const HamyarApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'همیار درس دهم',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: navy,
      colorScheme: ColorScheme.fromSeed(seedColor: purple, brightness: Brightness.dark),
      fontFamily: 'Roboto',
    ),
    home: const MainShell(),
  );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [HomePage(), CoursesPage(), TasksPage(), AdminPage()];
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      body: Stack(children: [
        const Positioned(top: -90, right: -70, child: GlowOrb(color: purple, size: 230)),
        const Positioned(bottom: 70, left: -110, child: GlowOrb(color: blue, size: 250)),
        SafeArea(child: IndexedStack(index: index, children: pages)),
      ]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF11172B),
        indicatorColor: purple.withOpacity(.22),
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.menu_book_rounded), label: 'درس‌ها'),
          NavigationDestination(icon: Icon(Icons.assignment_rounded), label: 'تکالیف'),
          NavigationDestination(icon: Icon(Icons.admin_panel_settings_rounded), label: 'مدیریت'),
        ],
      ),
    ),
  );
}

class GlowOrb extends StatelessWidget {
  final Color color; final double size;
  const GlowOrb({super.key, required this.color, required this.size});
  @override
  Widget build(BuildContext context) => IgnorePointer(child: Container(
    width: size, height: size,
    decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [
      BoxShadow(color: color.withOpacity(.20), blurRadius: 100, spreadRadius: 25),
    ]),
  ));
}

class GlassCard extends StatelessWidget {
  final Widget child; final EdgeInsets padding; final double radius;
  const GlassCard({super.key, required this.child, this.padding = const EdgeInsets.all(18), this.radius = 22});
  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(radius),
    child: BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.075),
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(color: Colors.white.withOpacity(.13)),
          gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft,
            colors: [Colors.white.withOpacity(.10), Colors.white.withOpacity(.035)]),
        ),
        child: child,
      ),
    ),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
    children: [
      Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
          Text('سلام دانش‌آموز 👋', style: TextStyle(color: muted, fontSize: 14)),
          SizedBox(height: 5),
          Text('همراه یادگیری تو', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
        ])),
        Container(width: 48, height: 48, decoration: BoxDecoration(
          color: purple.withOpacity(.18), borderRadius: BorderRadius.circular(16),
          border: Border.all(color: purple.withOpacity(.45))),
          child: const Icon(Icons.auto_stories_rounded, color: blue, size: 27)),
      ]),
      const SizedBox(height: 22),
      GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [Icon(Icons.bolt_rounded, color: blue), SizedBox(width: 8),
          Text('مسیر پیشرفت تو', style: TextStyle(fontWeight: FontWeight.bold))]),
        const SizedBox(height: 15),
        const Text('هر روز یک قدم جلوتر', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
        const SizedBox(height: 7),
        const Text('درس‌ها را مرور کن و برای آزمون آماده شو.', style: TextStyle(color: muted)),
        const SizedBox(height: 18),
        ClipRRect(borderRadius: BorderRadius.circular(20),
          child: const LinearProgressIndicator(value: .35, minHeight: 7,
            backgroundColor: Color(0xFF303653), color: blue)),
        const SizedBox(height: 8),
        const Text('نمونهٔ نمایشی پیشرفت · ۳۵٪', style: TextStyle(color: muted, fontSize: 12)),
      ])),
      const SizedBox(height: 22),
      const SectionTitle('دسترسی سریع'),
      const SizedBox(height: 12),
      Row(children: const [
        Expanded(child: QuickTile(icon: Icons.menu_book_rounded, title: 'درس‌های من', subtitle: '۵ درس', color: blue)),
        SizedBox(width: 12),
        Expanded(child: QuickTile(icon: Icons.assignment_turned_in_rounded, title: 'تکالیف', subtitle: '۴ مورد', color: purple)),
      ]),
      const SizedBox(height: 22),
      const SectionTitle('درس‌های پیشنهادی'),
      const SizedBox(height: 10),
      ...courseData.take(3).map((c) => CourseTile(course: c)),
      const SizedBox(height: 18),
      const GlassCard(child: Row(children: [
        Icon(Icons.info_outline_rounded, color: blue),
        SizedBox(width: 12),
        Expanded(child: Text('نسخهٔ اولیه همیار درس دهم؛ امکانات آنلاین در به‌روزرسانی بعدی اضافه می‌شوند.',
          style: TextStyle(color: muted, height: 1.5))),
      ])),
    ],
  );
}

class SectionTitle extends StatelessWidget {
  final String text; const SectionTitle(this.text, {super.key});
  @override Widget build(BuildContext context) => Text(text,
    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800));
}

class QuickTile extends StatelessWidget {
  final IconData icon; final String title, subtitle; final Color color;
  const QuickTile({super.key, required this.icon, required this.title, required this.subtitle, required this.color});
  @override Widget build(BuildContext context) => GlassCard(child: Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: color, size: 27), const SizedBox(height: 14),
      Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: muted, fontSize: 12)),
    ]));
}

class Course {
  final String title, description; final IconData icon;
  const Course(this.title, this.description, this.icon);
}
const courseData = [
  Course('زیست‌شناسی دهم', 'فصل‌ها، نکته‌ها و مرور مفاهیم زیست', Icons.biotech_rounded),
  Course('شیمی دهم', 'مفاهیم پایه، واکنش‌ها و تمرین‌ها', Icons.science_rounded),
  Course('فیزیک دهم', 'آموزش مفهومی و حل مسئله', Icons.bolt_rounded),
  Course('ریاضی دهم', 'درس‌نامه و تمرین‌های منتخب', Icons.functions_rounded),
  Course('فارسی دهم', 'معنی واژه‌ها، آرایه‌ها و دستور', Icons.translate_rounded),
];

class CourseTile extends StatelessWidget {
  final Course course; const CourseTile({super.key, required this.course});
  @override Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: GlassCard(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(children: [
        Container(width: 44, height: 44, decoration: BoxDecoration(
          color: purple.withOpacity(.18), borderRadius: BorderRadius.circular(14)),
          child: Icon(course.icon, color: blue)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(course.title, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4), Text(course.description, style: const TextStyle(color: muted, fontSize: 11)),
        ])),
        const Icon(Icons.chevron_left_rounded, color: muted),
      ]),
    ),
  );
}

class CoursesPage extends StatelessWidget {
  const CoursesPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('درس‌های پایه دهم', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6), const Text('رشته علوم تجربی', style: TextStyle(color: blue)),
    const SizedBox(height: 18), ...courseData.map((c) => CourseTile(course: c)),
    const SizedBox(height: 10),
    const Text('محتوای کامل درس‌ها در مرحلهٔ بعد به برنامه اضافه می‌شود.',
      style: TextStyle(color: muted, height: 1.5)),
  ]);
}

class TasksPage extends StatelessWidget {
  const TasksPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('تکالیف و آزمون‌ها', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
    const SizedBox(height: 16),
    const GlassCard(child: Row(children: [
      Icon(Icons.assignment_rounded, color: blue, size: 32), SizedBox(width: 12),
      Expanded(child: Text('فهرست نمونه تکالیف نسخهٔ اولیه', style: TextStyle(fontWeight: FontWeight.bold))),
    ])),
    const SizedBox(height: 12),
    ...[
      ('مرور فصل اول زیست‌شناسی', 'در انتظار', Icons.schedule_rounded),
      ('تمرین ساختار اتم شیمی', 'در انتظار', Icons.science_rounded),
      ('آزمونک ریاضی دهم', 'انجام‌شده', Icons.check_circle_outline_rounded),
      ('خلاصه درس اول فارسی', 'در انتظار', Icons.edit_note_rounded),
    ].map((a) => Padding(padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(child: ListTile(contentPadding: EdgeInsets.zero,
        leading: Icon(a.$3, color: a.$2 == 'انجام‌شده' ? blue : purple),
        title: Text(a.$1, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(a.$2, style: const TextStyle(color: muted)),
      )))),
    const Text('ارسال پاسخ و ثبت نمره در نسخهٔ آنلاین فعال خواهد شد.',
      style: TextStyle(color: muted, height: 1.5)),
  ]);
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('پنل مدیریت', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6), const Text('ابزارهای مدیریتی نسخهٔ اولیه', style: TextStyle(color: blue)),
    const SizedBox(height: 18),
    const GlassCard(child: Column(children: [
      CircleAvatar(radius: 32, backgroundColor: Color(0xFF493B83),
        child: Icon(Icons.admin_panel_settings_rounded, size: 34, color: Colors.white)),
      SizedBox(height: 12),
      Text('محمد شایان واحدی', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      SizedBox(height: 4), Text('سازنده برنامه', style: TextStyle(color: muted)),
    ])),
    const SizedBox(height: 16),
    _AdminOption(Icons.people_alt_rounded, 'مدیریت دانش‌آموزان', 'نمایش و مدیریت حساب‌ها'),
    _AdminOption(Icons.library_books_rounded, 'مدیریت درس‌ها', 'افزودن و ویرایش محتوای آموزشی'),
    _AdminOption(Icons.assignment_rounded, 'مدیریت تکالیف و آزمون‌ها', 'تعریف فعالیت‌های آموزشی'),
    _AdminOption(Icons.notifications_active_rounded, 'اطلاعیه‌ها', 'مدیریت پیام‌های برنامه'),
    _AdminOption(Icons.query_stats_rounded, 'آمار و گزارش‌ها', 'نمایش آمار نمونه'),
    const SizedBox(height: 12),
    const Text('توجه: این پنل در نسخهٔ فعلی محلی و نمایشی است؛ اتصال آنلاین و مدیریت واقعی کاربران در مرحلهٔ بعد ساخته می‌شود.',
      style: TextStyle(color: Color(0xFFFFC66D), height: 1.6)),
    const SizedBox(height: 20),
    const SectionTitle('درباره برنامه'),
    const SizedBox(height: 10),
    const GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('همیار درس دهم', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
      SizedBox(height: 8),
      Text('یک همراه آموزشی برای دانش‌آموزان پایه دهم رشته علوم تجربی؛ با هدف دسترسی ساده‌تر به درس‌ها، تکالیف و آزمون‌ها.',
        style: TextStyle(color: muted, height: 1.7)),
      SizedBox(height: 12),
      Divider(color: Color(0x334D5B82)),
      Text('سازنده: محمد شایان واحدی', style: TextStyle(fontWeight: FontWeight.bold, color: blue)),
      SizedBox(height: 5), Text('نسخه ۱.۰.۰', style: TextStyle(color: muted, fontSize: 12)),
    ])),
  ]);
}

class _AdminOption extends StatelessWidget {
  final IconData icon; final String title, subtitle;
  const _AdminOption(this.icon, this.title, this.subtitle);
  @override Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: GlassCard(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: ListTile(contentPadding: EdgeInsets.zero,
        leading: Icon(icon, color: blue, size: 25),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle, style: const TextStyle(color: muted, fontSize: 12)),
        trailing: const Icon(Icons.chevron_left_rounded, color: muted),
      )),
  );
}
